<?php

namespace App\Units\Styles;

use App\Units\Helpers\SizeHelper;

class PositionUnit
{
    public static function rander($props , $resize = false , $sizes = [])
    {
        $style = '';
        if(isset($props['x'])) {
            $x = $props['x'] . 'px; ';
            if($resize) {
                $x = SizeHelper::getWidth($props['x'] , $sizes) .'%; ';
            }
            $style .= 'left: ' . $x;
        }
        if(isset($props['y'])) {
            $style .= 'top: ' . $props['y'] . 'px; ';
        }
        $style .= 'position: absolute;';
        return $style;
    }
}
