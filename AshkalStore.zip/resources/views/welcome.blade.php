<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="{{$html['css']}}">
    <title>Document</title>
    <style>
        body {
            margin: 0;
            padding: 0;
        }
        p {
            margin: 0;
            padding: 0;
        }
    </style>
</head>
<body>
{!! $html['html'] !!}
</body>
</html>
