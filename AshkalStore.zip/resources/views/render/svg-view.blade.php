{!! base64_decode(substr($svgData, strpos($svgData, ",") + 1)) !!}
